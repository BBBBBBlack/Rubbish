#include <stdio.h>
#include <unistd.h>
int main() {
    int x = 5;
    if (fork()) {
        x += 30;
        //sleep(5);
        printf("%d\n", x);
        //sleep(5);
    }
    else
        printf("%d\n", x);
    printf("%d\n", x);
}
