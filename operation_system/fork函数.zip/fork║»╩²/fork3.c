#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<sys/types.h>
#include<sys/wait.h>
int main() {
	int fd[2];
	char buf[100];
	char s[100];
	pid_t pid;
	pipe(fd);
	pid = fork();
	if (pid > 0) {
		scanf("%s", s);
		close(fd[0]);
		write(fd[1], s, sizeof(s));
	}
	else if (pid == 0) {
		close(fd[1]);
		read(fd[0], buf, sizeof(buf));
		FILE* fp;
		fp = fopen("pipo.txt", "w+");
		fprintf(fp, "%s", buf);
		fclose(fp);
	}
	waitpid(pid, NULL, 0);
	return 0;
}
