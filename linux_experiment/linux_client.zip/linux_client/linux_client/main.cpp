﻿#include <cstdio>
#include<unistd.h>
#include<arpa/inet.h>
#include<string.h>
#include<stdlib.h>
#include<pthread.h>
#include<fcntl.h>
#include<errno.h>
#include<dirent.h>
#include<sys/stat.h>
#include<iostream>

#define ROOT_PATH "./download/"         //客户端文件下载根目录
#define MSG_TYPE_FNAME 1                //信息类型——查询文件
#define MSG_TYPE_DOWNLOAD 2             //信息类型——下载文件
#define MSG_TYPE_UPLOAD 3               //信息类型——上传文件
#define MSG_TYPE_UPLOAD_DATA 4          //信息类型——上传文件内容
#define MSG_TYPE_DELETE 6               //信息类型——删除文件
#define MSG_TYPE_LOGIN 7               //信息类型——登录


//客户端服务器端信息交互使用的结构体，两端结构完全一致
typedef struct msg {
    int type;           //信息类型
    int flag;           //标志位——目录文件读完为0，未读完为1
    char buffer[1024];  //文件内容
    char fname[50];     //文件名
    int bytes;          //文件总字节数
    char token[30];
}MSG;
typedef struct upload_param {
    int client_socket;
    char fname[50];
}param;

std::string token;
//打印网盘操作菜单
void net_disk_menu() {
    //system("clear");
    printf("\n================MY FIRST SB NET DISK================\n");
    printf("----------------        MENU        ----------------\n");
    printf("\t\t    1.查询文件\n");
    printf("\t\t    2.下载文件\n");
    printf("\t\t    3.上传文件\n");
    printf("\t\t    4.删除文件\n");
    printf("\t\t    5.清屏\n");
    printf("\t\t    6.退出系统\n");
    printf("====================================================\n");
    printf("请选择你要执行的操作（enter键调出菜单）：");
}
//向服务器端请求查询网盘目录下的文件
int read_file(int accept_socket);
//向服务器端请求下载某一文件
int download_file(int accept_socket);
//向服务器端提交上传文件请求（以便服务器先创建文件）
// 并生成上传参数配置
param upload_param(int accept_socket);
//向服务器端正式上传文件内容
void* upload_file(void* arg);
////向服务器端请求删除某一文件
int delete_file(int accept_socket);
//读客户端下载目录下的文件
void read_dir(int accept_socket);
//一个新的线程，接收并处理服务器应答
void* thread_func(void* arg);
//登录
bool login(int client_socket);
int main() {
    int client_socket;
    struct sockaddr_in server_addr;
    //创建套接字
    client_socket = socket(AF_INET, SOCK_STREAM, 0);
    if (client_socket < 0) {
        perror("client_socket error");
    }
    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = inet_addr("192.168.43.31");//服务器IP
    server_addr.sin_port = htons(8888);//端口号
    //连接服务器
    if (connect(client_socket, (struct sockaddr*)&server_addr, sizeof(server_addr)) < 0) {
        perror("connect failed");
    }
    printf("%s 向你问好!\n", "linux_client");
    pthread_t thread_id;
    pthread_create(&thread_id, NULL, thread_func, &client_socket);
    system("clear");
    while (token.empty()) {
        login(client_socket);
        sleep(3);
    }
    
    char buffer[50] = { 0 };
    bool open = true;
    //开始操作
    while (open && fgets(buffer, sizeof(buffer), stdin) != NULL) {
        int res = 0;
        switch (buffer[0]) {
        case '\n': {
            net_disk_menu();
            break;
        }
        case '1': {
            read_file(client_socket);
            break;
        }
        case '2': {
            //打印服务端文件列表
            read_file(client_socket);
            printf("input the name of the file you want to download:\n");
            //下载文件
            res = download_file(client_socket);
            break;
        }
        case '3': {
            printf("input the name of the file you want to upload:\n");
            //打印客户端下载文件目录
            read_dir(client_socket);
            param p = upload_param(client_socket);
            pthread_t thread_send_id;
            //创建新线程上传文件
            pthread_create(&thread_send_id, NULL, upload_file, &p);
            break;
        }
        case '4': {
            read_file(client_socket);
            printf("input the name of the file you want to delete:\n");
            res = delete_file(client_socket);
            break;
        }
        case '5': {
            system("clear");
            net_disk_menu();
            break;
        }
        case '6': {
            open = false;
            break;
        }
        }
        if (res < 0) {
            perror("send failed");
        }
        memset(buffer, 0, sizeof(buffer));
    }
    return 0;
}
//查询文件
int read_file(int accept_socket) {
    MSG send = { 0 };
    send.type = MSG_TYPE_FNAME;
    strcpy(send.token , token.c_str());
    return write(accept_socket, &send, sizeof(send));
}
//下载文件
int download_file(int accept_socket) {
    MSG send = { 0 };
    strcpy(send.token, token.c_str());
    send.type = MSG_TYPE_DOWNLOAD;
    //输入要下载的文件名
    fgets(send.fname, sizeof(send.fname), stdin);
    send.fname[strcspn(send.fname, "\n")] = '\0';
    //发送下载请求
    return write(accept_socket, &send, sizeof(send));
}
//上传文件
void* upload_file(void* arg) {
    param* p = (param*)arg;
    int client_socket = p->client_socket;
    int fd = 0;
    std::string root = ROOT_PATH;
    std::string fname(p->fname);
    std::string path = root + fname;
    fd = open(path.c_str(), O_RDONLY);
    if (fd < 0) {
        perror("open failed");
    }
    int res = 0;
    MSG upload = { 0 };
    strcpy(upload.token, token.c_str());
    upload.type = MSG_TYPE_UPLOAD_DATA;
    strcpy(upload.fname, p->fname);
    while ((res = read(fd, upload.buffer, sizeof(upload.buffer))) > 0) {
        upload.bytes = res;
        write(client_socket, &upload, sizeof(upload));
        memset(upload.buffer, 0, sizeof(upload.buffer));
    }
}
//上传文件参数配置
param upload_param(int accept_socket) {
    MSG send = { 0 };
    strcpy(send.token, token.c_str());
    send.type = MSG_TYPE_UPLOAD;
    fgets(send.fname, sizeof(send.fname), stdin);
    send.fname[strcspn(send.fname, "\n")] = '\0';
    write(accept_socket, &send, sizeof(send));
    param p = { 0 };
    p.client_socket = accept_socket;
    strcpy(p.fname, send.fname);
    return p;
}
//删除文件
int delete_file(int accept_socket) {
    MSG send = { 0 };
    strcpy(send.token, token.c_str());
    send.type = MSG_TYPE_DELETE;
    //用户输入删除文件名
    fgets(send.fname, sizeof(send.fname), stdin);
    send.fname[strcspn(send.fname, "\n")] = '\0';
    //发送给服务器
    return write(accept_socket, &send, sizeof(send));
}
//处理服务器应答
void* thread_func(void* arg) {
    int client_socket = *((int*)arg);
    MSG recv = { 0 };
    int fd = -1;
    //int errno = 0;
    while (1) {
        int res = read(client_socket, &recv, sizeof(recv));
        if (recv.type == MSG_TYPE_FNAME) {
            if (recv.flag != 0 && res > 0) {
                printf("%s\n", recv.fname);
                memset(recv.fname, 0, sizeof(recv.fname));
            }
            else {
                printf("====================================================\n");
            }
        }
        else if (recv.type == MSG_TYPE_DOWNLOAD) {
            if (mkdir("download", S_IRWXU) < 0) {//O_CREAT | O_WRONLY
                if (errno != EEXIST) {
                    perror("mkdir failed");
                }
            }
            //文件还未打开
            if (fd == -1) {
                std::string root = "./download/";
                std::string fname = recv.fname;
                std::string path = root + fname;
                fd = open(path.c_str(), O_CREAT | O_WRONLY);
                if (fd < 0) {
                    perror("open failed");
                }
            }
            if (!recv.flag) {
                printf("download file %s failed\n",recv.fname);
            }
            else {
                res = write(fd, recv.buffer, recv.bytes);
                if (res < 0) {
                    perror("write failed");
                }
                if (recv.bytes < sizeof(recv.buffer)) {
                    close(fd);
                    fd = -1;
                    printf("download file %s sucess\n", recv.fname);
                }
            }
        }
        else if (recv.type == MSG_TYPE_UPLOAD) {
            printf("upload file %s sucess\n", recv.fname);
        }
        else if (recv.type == MSG_TYPE_DELETE) {
            if (recv.flag) {
                printf("delete file %s sucess\n", recv.fname);
            }
            else {
                printf("delete file %s wrong\n", recv.fname);
            }
        }
        else if (recv.type == MSG_TYPE_LOGIN) {
            if (!recv.flag) {
                printf("login failed\n");
            }
            else {
                token = recv.token;
                printf("login sucess\n");
            }
        }
        memset(&recv, 0, sizeof(recv));
    }
}
//读download下文件目录
void read_dir(int accept_socket) {
    printf("MY DOWNLOAD NET DISK:\n");
    struct dirent* dir = NULL;
    DIR* dp = opendir(ROOT_PATH);
    if (dp == NULL) {
        perror("open failed");
        return;
    }
    while (1) {
        dir = readdir(dp);
        if (dir == NULL) {
            break;
        }
        else if (dir->d_name[0] != '.') {
            printf("%s\n", dir->d_name);
        }
    }
    printf("====================================================\n");
}
bool login(int accept_socket) {
    char username[30] = { 0 };
    char password[30] = { 0 };
    printf("Enter your userName:\n");
    fgets(username, sizeof(username), stdin);
    username[strlen(username) - 1] = '\0';
    printf("Enter your password:\n");
    fgets(password, sizeof(password), stdin);
    password[strlen(password) - 1] = '\0';
    MSG login = { 0 };
    login.type = MSG_TYPE_LOGIN;
    strcpy(login.fname, username);
    strcpy(login.buffer, password);
    write(accept_socket, &login, sizeof(login));
}
//void read_dir(int client_socket) {
    //    MSG recv = { 0 };
    //    while (1) {
    //        int res = read(client_socket, &recv, sizeof(MSG));
    //        if (res <= 0 || &recv == NULL || recv.flag == 0) {
    //            break;
    //        }
    //        if (recv.type == MSG_TYPE_FNAME) {
    //            printf("%s\n", recv.fname);
    //            memset(&recv, 0, sizeof(recv));
    //        }
    //    }
    //}