﻿#include<cstdio>
#include <sys/types.h>          /* See NOTES */
#include <sys/socket.h>
#include <string.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <signal.h>
#include<pthread.h>
#include<dirent.h>
#include<iostream>
#include<fcntl.h>
#include <thread>
#include <mutex>
#include <condition_variable>
#include <queue>
#include <iostream>
#include <fstream>
#include<time.h>
#include <map>
#include <set>
#include <random>



#define ROOT_PATH "/home/bbbbbblack/"   //服务器文件存放根目录
#define MSG_TYPE_FNAME 1                //信息类型——查询文件
#define MSG_TYPE_DOWNLOAD 2             //信息类型——下载文件
#define MSG_TYPE_UPLOAD 3               //信息类型——上传文件
#define MSG_TYPE_UPLOAD_DATA 4          //信息类型——上传文件内容
#define MSG_TYPE_DELETE 6               //信息类型——删除文件
#define MSG_TYPE_LOGIN 7               //信息类型——登录

std::mutex mtx;
std::condition_variable cv;
std::queue<std::string> logQueue;
std::map<std::string, std::string> credentials;
std::set<std::string> token;

char log_buf[1024];
// 管道文件描述符
int pipefd[2];
FILE* logfile;
//客户端服务器端信息交互使用的结构体，两端结构完全一致
typedef struct msg {
    int type;           //信息类型
    int flag;       //标志位——目录文件读完为0，未读完为1；出错为0，无错为1
    char buffer[1024];  //文件内容
    char fname[50];     //文件名
    int bytes;          //文件总字节数
    char token[30];
}MSG;

//一个新的线程，调用
// search_dir、send_file、recv_file、write_file、delete_file
// 循环处理某一socket发来的数据包
void* thread_func(void* arg);
//扫描根目录下的文件并发送给客户端
void search_dir(int accept_socket);
//对于客户端下载文件的请求，将文件内容传给客户端
void send_file(MSG recv, int accept_socket);
//对于客户端上传文件的请求，新建一个文件
int create_file(MSG recv, int accept_socket);
//接收客户端上传文件的内容，写入recv_file所创建的文件中
void write_file(int fd, MSG recv,int accept_socket);
//对于客户端删除文件的请求，将指定文件删除
void delete_file(MSG recv, int accept_socket);
//登录
void login(MSG recv, int ccept_socket);
//日志线程
void* logThread(void* arg);
//写日志
void log(const std::string& message);
//当前时间
std::string get_current_time(tm in);
//退出处理
void signalHandler(int signal);
void read_config();
std::string get_random(int length);
int main() {

    //创建管道
    pipe(pipefd);
    //stderr重定向到管道
    dup2(pipefd[1], STDERR_FILENO);
    //打开日志文件
    logfile = fopen("log", "w");
    //日志线程启动
    pthread_t thread_log_id;
    pthread_create(&thread_log_id, NULL, logThread, NULL);
    signal(SIGINT, signalHandler);
    read_config();
    //创建套接字
    int server_socket = socket(AF_INET, SOCK_STREAM, 0);
    if (server_socket < 0) {
        log("create socket failed");
        return 0;
    }
    struct sockaddr_in server_addr;
    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = INADDR_ANY;
    server_addr.sin_port = htons(8888);
    //端口号复用
    int optvalue = 1;
    setsockopt(server_socket, SOL_SOCKET, SO_REUSEADDR, &optvalue, sizeof(optvalue));
    //server_socket绑定IP和端口号
    if (bind(server_socket, (struct sockaddr*) & server_addr, sizeof(server_addr)) < 0) {
        log("bind failed");
        return 0;
    }
    //监听程序
    if (listen(server_socket, 10) < 0) {
        log("listen failed");
        return 0;
    }
    printf("%s 向你问好！\n", "linux_server");
    pthread_t thread_id;
    while (1) {
        int accept_socket = accept(server_socket, NULL, NULL);
        pthread_create(&thread_id, NULL, thread_func, &accept_socket);
    }
    return 0;
}
//处理请求
void* thread_func(void* arg) {
    int accept_socket = *((int*)arg);
    MSG recv = { 0 };
    int fd;
    while (1) {
        int char_num = read(accept_socket, &recv, sizeof(recv));
        if (char_num == 0) {
            break;
        }
        if (recv.type != MSG_TYPE_LOGIN && token.find(recv.token) == token.end()) {
            continue;
        }
        if (recv.type==MSG_TYPE_FNAME) {
            search_dir(accept_socket);
        }
        else if (recv.type == MSG_TYPE_DOWNLOAD) {
            send_file(recv,accept_socket);
        }
        else if (recv.type == MSG_TYPE_UPLOAD) {
            fd = create_file(recv, accept_socket);
        }
        else if (recv.type == MSG_TYPE_UPLOAD_DATA) {
            write_file(fd, recv, accept_socket);
        }
        else if (recv.type == MSG_TYPE_DELETE) {
            delete_file(recv, accept_socket);
        }
        else if (recv.type == MSG_TYPE_LOGIN) {
            login(recv, accept_socket);
        }
        memset(&recv, 0, sizeof(recv));
    }
}
//写文件
void write_file(int fd, MSG recv,int accept_socket) {
    printf("recieve!!!%d\n", sizeof(recv.buffer));
    write(fd, recv.buffer, recv.bytes);
    if (recv.bytes < sizeof(recv.buffer)) {
        printf("upload success\n");
        MSG send = { 0 };
        send.type = MSG_TYPE_UPLOAD;
        send.flag = 1;
        strcpy(send.fname, recv.fname);
        write(accept_socket, &send, sizeof(send));
        close(fd);
    }
}
//收文件
int create_file(MSG recv, int accept_socket) {
    std::string fname = recv.fname;
    //上传文件所在路径
    std::string path = ROOT_PATH + fname;
    //新建文件
    int fd = open(path.c_str(), O_CREAT | O_WRONLY, 0666);
    if (fd < 0) {
        log("create file " + path + " failed");
    }
    return fd;
}
//传文件
void send_file(MSG recv, int accept_socket) {
    MSG file = { 0 };
    file.type = MSG_TYPE_DOWNLOAD;
    file.flag = 1;
    std::string fname = recv.fname;
    //客户端要下载文件的路径
    std::string path = ROOT_PATH + fname; 
    strcpy(file.fname, fname.c_str());
    int fd = open(path.c_str(), O_RDONLY);
    //文件打开失败
    if (fd < 0) {
        log("open file " + path + " failed");
        file.flag = 0;
    }
    else {
        strcpy(file.fname, fname.c_str());
        int res = 0;
        while ((res = read(fd, file.buffer, sizeof(file.buffer))) > 0) {
            file.bytes = res;
            res = write(accept_socket, &file, sizeof(file));
            printf("file sent:%d\n", res);
            memset(file.buffer, 0, sizeof(file.buffer));
            //文件写入失败
            if (res <= 0) {
                log("send msg failed");
                file.flag = 0;
                break;
            }
        }
    }
    //操作失败向客户端发送信息
    if (!file.flag) {
        write(accept_socket, &file, sizeof(file));
    }
}
//读文件
void search_dir(int accept_socket) {
    MSG info = { 0 };
    info.type = MSG_TYPE_FNAME;
    struct dirent* dir = NULL;
    //DIR* dp = opendir("/opt/my_net_disk");
    DIR* dp = opendir(ROOT_PATH);
    if (dp == NULL) {
        log("open dir failed");
        return;
    }
    while (1) {
        dir = readdir(dp);
        memset(info.fname, 0, sizeof(info.fname));
        if (dir == NULL) {
            info.flag = 0;
            write(accept_socket, &info, sizeof(info));
            break;
        }
        else if (dir->d_name[0] != '.') {
            info.flag = 1;
            strcpy(info.fname, dir->d_name);
            int res = write(accept_socket, &info, sizeof(info));
            if (res < 0) {
                log("write msg failed");
                break;
            }
        }
    }
    memset(info.fname, 0, sizeof(info.fname));
}
//删文件
void delete_file(MSG recv, int accept_socket) {
    std::string fname = recv.fname;
    std::string path = ROOT_PATH + fname;
    MSG send = { 0 };
    send.type = MSG_TYPE_DELETE;
    strcpy(send.fname, recv.fname);
    send.flag = 1;
    int res = remove(path.c_str());
    //删除失败
    if (res < 0) {
        send.flag = 0;
        log("delete " + path + " failed");
    }
    write(accept_socket, &send, sizeof(send));
}
//登录
void login(MSG recv, int accept_socket) {
    MSG send = { 0 };
    send.type = MSG_TYPE_LOGIN;
    //密码正确？
    if ((credentials.count(recv.fname) > 0 && credentials[recv.fname] == recv.buffer)) {
        //返回token并存入Set<string> token
        send.flag = 1;
        std::string stoken = get_random(20);
        strcpy(send.token, stoken.c_str());
        printf("token:%s\n", stoken.c_str());
        token.insert(stoken);
    }
    else {
        send.flag = 0;
    }
    int res = write(accept_socket, &send, sizeof(send));
    if (res < 0) {
        perror("login?");
    }
}
//日志线程
void* logThread(void* arg) {
    while (true) {
        std::unique_lock<std::mutex> lock(mtx);
        memset(log_buf, 0, sizeof(log_buf));
        cv.wait(lock, [] { return read(pipefd[0], log_buf, sizeof(log_buf)) > 0; }); // 阻塞等待日志
        printf("----------------%s\n", log_buf);
        fwrite(log_buf, strlen(log_buf) + 1, 1, logfile);
        lock.unlock();   
        //fclose(logfile);
    }
}
//写日志
void log(const std::string& message) {
    time_t t = time(NULL);
    std::string log = get_current_time(*localtime(&t)) + message;
    //strerr写入管道
    int res = write(pipefd[1], log.c_str(), log.length());
    cv.notify_one(); // 唤醒日志线程
}
std::string get_current_time(tm in){
    tm* ct = &in;
    int year, month, day, hour, minute, second;// 年月日时分秒。
    year = ct->tm_year + 1900;                 // 年份基础从1900开始的，所以要加上
    month = ct->tm_mon + 1;                    // 月份是0-11，对应1-12月
    day = ct->tm_mday;
    hour = ct->tm_hour;
    minute = ct->tm_min;
    second = ct->tm_sec;

    char temp[100];                            // 创建字符数组。
    sprintf(temp, "%04d-%02d-%02d %02d:%02d:%02d: ", year, month, day, hour, minute, second);// 时间信息合并。
    std::string out(temp);                          // 转化为string型
    return std::move(out);                          // 用move（string）速度快很多。
}
void signalHandler(int signal) {
    if (signal == SIGINT) {
        // 关闭文件
        if (logfile != NULL) {
            fclose(logfile);
            close(pipefd[1]);
            close(pipefd[2]);
        }
        exit(0);
    }
}
void read_config() {
    std::ifstream file("my.txt");
    std::string line;

    while (std::getline(file, line)) {
        size_t separatorPos = line.find(':');
        if (separatorPos != std::string::npos) {
            std::string username = line.substr(0, separatorPos);
            std::string password = line.substr(separatorPos + 1);
            credentials[username] = password;
        }
    }
}
std::string get_random(int length) {
    std::string chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    std::random_device rd;
    std::mt19937 gen(rd());
    std::uniform_int_distribution<> dis(0, chars.length() - 1);
    std::string result;
    for (int i = 0; i < length; ++i) {
        result += chars[dis(gen)];
    }
    return result;
}
